from preflibtools.instances import PrefLibInstance
instance = OrdinalInstance()
instance.populate_IC(5, 10)