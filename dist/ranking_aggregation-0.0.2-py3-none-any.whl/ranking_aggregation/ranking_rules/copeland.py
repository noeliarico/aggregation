def copeland(profile):
    return 0