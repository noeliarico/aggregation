import numpy as np

def average_position():
    return 0