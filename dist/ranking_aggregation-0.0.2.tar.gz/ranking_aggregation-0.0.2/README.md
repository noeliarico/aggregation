# Quick installation

```
pip install aggregation
```

