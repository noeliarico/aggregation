# def test_score_borda():
#     x = 2
#     assert x == 2

# def test_score_condorcet():
#     x = 2
#     assert x == 2