import numpy as np

def hello2():
    """This is an example function...
    """
    print("Ciao tutti 2!")