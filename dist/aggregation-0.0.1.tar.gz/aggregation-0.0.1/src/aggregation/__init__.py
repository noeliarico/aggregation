"""A package from dempster shafer.

.. moduleauthor:: Noelia Rico <noeliarico@uniovi.es>
.. moduleauthor:: Luigi Troiano <ltroiano@unisa.it>

"""

def hello():
    """This is an example function...
    """
    print("Ciao tutti!")
    
def hello3():
    """This is an example function...
    """
    print("Ciao tutti!")